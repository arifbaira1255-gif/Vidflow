import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'admin.dart';
import 'home.dart';
import 'models.dart';
import 'repo.dart';
import 'theme.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});
  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  late Future<List<Video>> f = Repo.savedVideos();
  @override
  Widget build(BuildContext context) => SafeArea(
        child: RefreshIndicator(
          color: C.accent,
          onRefresh: () async { setState(() => f = Repo.savedVideos()); await f; },
          child: FutureBuilder<List<Video>>(
            future: f,
            builder: (_, s) {
              if (!s.hasData) return const Center(child: CircularProgressIndicator(color: C.accent));
              if (s.data!.isEmpty) return ListView(children: const [SizedBox(height: 200), Center(child: Text('Videos you save appear here.', style: TextStyle(color: C.muted)))]);
              return ListView(physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()), children: [
                const Padding(padding: EdgeInsets.all(16), child: Text('Watch later', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
                for (final v in s.data!) VideoCard(v),
              ]);
            },
          ),
        ),
      );
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final email = Repo.uid == null ? '' : ((Supabase.instance.client.auth.currentUser?.email ?? ''));
    return SafeArea(
      child: ListView(padding: const EdgeInsets.all(20), children: [
        const SizedBox(height: 12),
        const Center(child: CircleAvatar(radius: 44, backgroundColor: C.accent, child: Icon(Icons.person, size: 44, color: C.bg))),
        const SizedBox(height: 12),
        Center(child: Text(email, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600))),
        const SizedBox(height: 24),
        FutureBuilder<bool>(
          future: Repo.isAdmin(),
          builder: (_, s) => s.data == true
              ? ListTile(
                  leading: const Icon(Icons.admin_panel_settings_outlined, color: C.accent), title: const Text('Admin panel'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminScreen())))
              : const SizedBox.shrink(),
        ),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: Repo.signOut),
      ]),
    );
  }
}
