import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'models.dart';
import 'repo.dart';
import 'theme.dart';
import 'ads.dart';

class WatchScreen extends StatefulWidget {
  final Video video;
  const WatchScreen(this.video, {super.key});
  @override
  State<WatchScreen> createState() => _WatchScreenState();
}

class _WatchScreenState extends State<WatchScreen> {
  late final YoutubePlayerController _yt;
  int like = 0, dislike = 0, mine = 0;
  bool saved = false, following = false, loading = true;
  List<Comment> comments = [];
  final input = TextEditingController();

  @override
  void initState() {
    super.initState();
    _yt = YoutubePlayerController(
      initialVideoId: widget.video.ytId,
      flags: const YoutubePlayerFlags(autoPlay: true, enableCaption: false),
    );
    _load();
  }

  Future<void> _load() async {
    final id = widget.video.id;
    try {
      final r = await Repo.reactions(id);
      final c = await Repo.comments(id);
      final sv = await Repo.isSaved(id);
      final fo = await Repo.isFollowing(widget.video.owner);
      Repo.view(id);
      if (!mounted) return;
      setState(() { like = r['like']!; dislike = r['dislike']!; mine = r['mine']!; comments = c; saved = sv; following = fo; });
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> _react(int v) async {
    final next = mine == v ? 0 : v;
    setState(() {
      if (mine == 1) like--;
      if (mine == -1) dislike--;
      if (next == 1) like++;
      if (next == -1) dislike++;
      mine = next;
    });
    await Repo.react(widget.video.id, next);
  }

  Future<void> _send() async {
    final t = input.text.trim();
    if (t.isEmpty) return;
    input.clear();
    await Repo.addComment(widget.video.id, t);
    final c = await Repo.comments(widget.video.id);
    if (mounted) setState(() => comments = c);
  }

  @override
  void dispose() {
    _yt.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = widget.video;
    return YoutubePlayerBuilder(
      player: YoutubePlayer(controller: _yt, showVideoProgressIndicator: true, progressIndicatorColor: C.accent),
      builder: (context, player) => Scaffold(
        body: SafeArea(
          child: Column(children: [
            player,
            Expanded(
              child: ListView(physics: const BouncingScrollPhysics(), padding: const EdgeInsets.all(16), children: [
                Text(v.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, height: 1.3)),
                const SizedBox(height: 6),
                Text('${v.views} · ${v.age}', style: const TextStyle(color: C.muted)),
                const SizedBox(height: 14),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(children: [
                    ChoiceChip(avatar: Icon(Icons.thumb_up_alt_outlined, size: 18, color: mine == 1 ? C.bg : C.text), label: Text('$like'),
                        selected: mine == 1, showCheckmark: false, selectedColor: C.accent, labelStyle: TextStyle(color: mine == 1 ? C.bg : C.text), onSelected: (_) => _react(1)),
                    const SizedBox(width: 8),
                    ChoiceChip(avatar: Icon(Icons.thumb_down_alt_outlined, size: 18, color: mine == -1 ? C.bg : C.text), label: Text('$dislike'),
                        selected: mine == -1, showCheckmark: false, selectedColor: C.coral, labelStyle: TextStyle(color: mine == -1 ? C.bg : C.text), onSelected: (_) => _react(-1)),
                    const SizedBox(width: 8),
                    ActionChip(
                      avatar: Icon(saved ? Icons.bookmark : Icons.bookmark_border, size: 18),
                      label: const Text('Watch later'),
                      onPressed: () { setState(() => saved = !saved); Repo.setSaved(v.id, saved); },
                    ),
                    const SizedBox(width: 8),
                    ActionChip(avatar: const Icon(Icons.share_outlined, size: 18), label: const Text('Share'), onPressed: () => Share.share('Watch "${v.title}" on VidFlow')),
                  ]),
                ),
                const SizedBox(height: 14),
                Row(children: [
                  CircleAvatar(backgroundColor: C.accent.withOpacity(.2), child: Text(v.channel[0].toUpperCase(), style: const TextStyle(color: C.accent))),
                  const SizedBox(width: 12),
                  Expanded(child: Text(v.channel, style: const TextStyle(fontWeight: FontWeight.w600))),
                  if (v.owner != Repo.uid)
                    FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: following ? C.surface : C.accent, foregroundColor: following ? C.text : C.bg),
                      onPressed: () { setState(() => following = !following); Repo.setFollowing(v.owner, following); },
                      child: Text(following ? 'Following' : 'Follow'),
                    ),
                ]),
                ExpansionTile(
                  tilePadding: EdgeInsets.zero, shape: const Border(), collapsedShape: const Border(),
                  title: const Text('Description'),
                  children: [Align(alignment: Alignment.centerLeft, child: Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(v.desc.isEmpty ? 'No description.' : v.desc, style: const TextStyle(color: C.muted))))],
                ),
                Text('${comments.length} comments', style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(controller: input, onSubmitted: (_) => _send(),
                    decoration: InputDecoration(hintText: 'Add a comment', suffixIcon: IconButton(icon: const Icon(Icons.send, color: C.accent), onPressed: _send))),
                if (loading) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: C.accent))),
                for (final c in comments)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: CircleAvatar(radius: 16, backgroundColor: C.surface, child: Text(c.user[0].toUpperCase())),
                    title: Text('@${c.user}', style: const TextStyle(fontSize: 12, color: C.muted)),
                    subtitle: Text(c.text, style: const TextStyle(color: C.text)),
                  ),
                const SizedBox(height: 12),
                const BannerAdBox(),
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
