import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class C {
  static const bg = Color(0xFF0B1F33);
  static const surface = Color(0xFF13324F);
  static const accent = Color(0xFF17C3B2);
  static const coral = Color(0xFFFF6B57);
  static const text = Color(0xFFF2EFE8);
  static const muted = Color(0xFF8DA2B8);
}

class SmoothScroll extends ScrollBehavior {
  const SmoothScroll();
  @override
  ScrollPhysics getScrollPhysics(BuildContext context) => const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics());
}

ThemeData vidflowTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  final r = BorderRadius.circular(14);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(primary: C.accent, surface: C.surface),
    textTheme: GoogleFonts.soraTextTheme(base.textTheme).apply(bodyColor: C.text, displayColor: C.text),
    inputDecorationTheme: InputDecorationTheme(
      filled: true, fillColor: C.surface,
      border: OutlineInputBorder(borderRadius: r, borderSide: BorderSide.none),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: r), backgroundColor: C.accent, foregroundColor: C.bg),
    ),
    chipTheme: base.chipTheme.copyWith(
      backgroundColor: C.surface, side: BorderSide.none, shape: const StadiumBorder(),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: C.surface, height: 64,
      indicatorColor: C.accent.withOpacity(.2),
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
    ),
  );
}
