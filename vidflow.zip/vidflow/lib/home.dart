import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'models.dart';
import 'player.dart';
import 'repo.dart';
import 'theme.dart';
import 'ads.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String cat = 'For You', q = '';
  List<Video> all = [];
  bool loading = true, searching = false;

  Future<void> _load() async {
    try {
      final v = await Repo.videos(popular: cat == 'For You');
      if (mounted) setState(() { all = v; loading = false; });
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = all.where((v) => (cat == 'All' || cat == 'For You' || v.category == cat) && v.title.toLowerCase().contains(q.toLowerCase())).toList();
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        color: C.accent, backgroundColor: C.surface, onRefresh: _load,
        child: CustomScrollView(
          cacheExtent: 900,
          physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
          slivers: [
            SliverAppBar(
              floating: true, snap: true, backgroundColor: C.bg, surfaceTintColor: Colors.transparent,
              titleSpacing: 16,
              title: searching
                  ? TextField(autofocus: true, onChanged: (s) => setState(() => q = s),
                      decoration: const InputDecoration(hintText: 'Search videos', isDense: true, prefixIcon: Icon(Icons.search)))
                  : const Text('VidFlow', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: C.accent)),
              actions: [
                IconButton(
                  icon: Icon(searching ? Icons.close : Icons.search),
                  onPressed: () => setState(() { searching = !searching; if (!searching) q = ''; }),
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 48,
                child: ListView(
                  scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
                  children: [
                    for (final c in categories)
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: ChoiceChip(
                          label: Text(c), selected: cat == c, selectedColor: C.accent, showCheckmark: false,
                          labelStyle: TextStyle(color: cat == c ? C.bg : C.text, fontWeight: FontWeight.w600),
                          onSelected: (_) { final reload = (c == 'For You') != (cat == 'For You'); setState(() => cat = c); if (reload) _load(); },
                        ),
                      ),
                  ],
                ),
              ),
            ),
            if (loading)
              const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator(color: C.accent)))
            else if (list.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: Center(child: Padding(padding: EdgeInsets.all(32), child: Text('No videos yet. Tap Upload to share the first one.', textAlign: TextAlign.center, style: TextStyle(color: C.muted)))),
              )
            else
              SliverList.builder(
                itemCount: list.length,
                itemBuilder: (_, i) => Column(children: [
                  VideoCard(list[i]),
                  if (i % 5 == 4) const Padding(padding: EdgeInsets.only(bottom: 20), child: BannerAdBox()),
                ]),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 24)),
          ],
        ),
      ),
    );
  }
}

class VideoCard extends StatelessWidget {
  final Video v;
  const VideoCard(this.v, {super.key});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => WatchScreen(v))),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 22),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: CachedNetworkImage(imageUrl: v.thumb, fit: BoxFit.cover, fadeInDuration: const Duration(milliseconds: 150),
                    placeholder: (_, __) => Container(color: C.surface), errorWidget: (_, __, ___) => Container(color: C.surface)),
              ),
            ),
            const SizedBox(height: 12),
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              CircleAvatar(radius: 18, backgroundColor: C.accent.withOpacity(.2), child: Text(v.channel[0].toUpperCase(), style: const TextStyle(color: C.accent, fontWeight: FontWeight.w700))),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, height: 1.3)),
                  const SizedBox(height: 4),
                  Text('${v.channel} · ${v.views} · ${v.age}', style: const TextStyle(color: C.muted, fontSize: 12)),
                ]),
              ),
            ]),
          ]),
        ),
      );
}
