import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';

const supabaseUrl = 'https://ozwfmlapoxyzmsikfijn.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im96d2ZtbGFwb3h5em1zaWtmaWpuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg1NTY0MDQsImV4cCI6MjA3NDEzMjQwNH0.l5x9FYMmWqc20Z3GVtGJmju3p7mO8-mkrZ3Pa096l2Q';

class Comment {
  final String user, text;
  Comment(this.user, this.text);
}

/// Returns the 11-character video id from watch, youtu.be, shorts, embed or live links.
String? extractYoutubeId(String url) {
  final u = Uri.tryParse(url.trim());
  if (u == null) return null;
  final ok = RegExp(r'^[A-Za-z0-9_-]{11}$');
  if (u.host.contains('youtu.be')) {
    return u.pathSegments.isNotEmpty && ok.hasMatch(u.pathSegments.first) ? u.pathSegments.first : null;
  }
  if (u.host.contains('youtube.com')) {
    final v = u.queryParameters['v'];
    if (v != null && ok.hasMatch(v)) return v;
    final s = u.pathSegments;
    if (s.length >= 2 && const ['shorts', 'embed', 'live', 'v'].contains(s.first) && ok.hasMatch(s[1])) return s[1];
  }
  return null;
}

class Repo {
  static SupabaseClient get _db => Supabase.instance.client;
  static String? get uid => _db.auth.currentUser?.id;

  static Future<void> signIn(String e, String p) => _db.auth.signInWithPassword(email: e, password: p);
  static Future<void> signUp(String e, String p, String name) => _db.auth.signUp(email: e, password: p, data: {'username': name});
  static Future<void> signOut() => _db.auth.signOut();

  static Video _map(Map<String, dynamic> r) => Video(
      r['id'], r['title'], r['profiles']?['username'] ?? 'VidFlow', r['thumbnail_url'], r['youtube_id'],
      r['category'] ?? 'All', '${r['views']} views', r['created_at'].toString().substring(0, 10),
      r['description'] ?? '', r['owner']);

  static Future<List<Video>> videos({bool shorts = false, bool popular = false}) async {
    final q = _db.from('videos').select('*, profiles(username)').eq('is_short', shorts);
    final rows = await (popular ? q.order('views', ascending: false) : q.order('created_at', ascending: false)).limit(40);
    return rows.map<Video>(_map).toList();
  }

  static Future<List<Video>> savedVideos() async {
    final rows = await _db.from('saves').select('videos(*, profiles(username))').eq('user_id', uid!);
    return rows.where((r) => r['videos'] != null).map<Video>((r) => _map(r['videos'])).toList();
  }

  static Future<bool> isAdmin() async {
    if (uid == null) return false;
    final r = await _db.from('profiles').select('is_admin').eq('id', uid!).maybeSingle();
    return r?['is_admin'] == true;
  }

  static Future<void> addVideo({required String title, required String category, required bool isShort, required String url, required String ytId}) =>
      _db.from('videos').insert({
        'title': title, 'category': category, 'is_short': isShort, 'youtube_url': url, 'youtube_id': ytId,
        'thumbnail_url': 'https://img.youtube.com/vi/$ytId/hqdefault.jpg', 'owner': uid,
      });

  /// like, dislike, mine (1 liked, -1 disliked, 0 none)
  static Future<Map<String, int>> reactions(String vid) async {
    final rows = await _db.from('reactions').select('value,user_id').eq('video_id', vid);
    var l = 0, d = 0, m = 0;
    for (final r in rows) {
      if (r['value'] == 1) { l++; } else { d++; }
      if (r['user_id'] == uid) m = r['value'];
    }
    return {'like': l, 'dislike': d, 'mine': m};
  }

  static Future<void> react(String vid, int v) async {
    if (v == 0) {
      await _db.from('reactions').delete().match({'video_id': vid, 'user_id': uid!});
    } else {
      await _db.from('reactions').upsert({'video_id': vid, 'user_id': uid, 'value': v});
    }
  }

  static Future<List<Comment>> comments(String vid) async {
    final rows = await _db.from('comments').select('body, profiles(username)').eq('video_id', vid).order('created_at', ascending: false);
    return rows.map<Comment>((r) => Comment(r['profiles']?['username'] ?? 'user', r['body'])).toList();
  }

  static Future<void> addComment(String vid, String body) => _db.from('comments').insert({'video_id': vid, 'user_id': uid, 'body': body});

  static Future<bool> isSaved(String vid) async =>
      (await _db.from('saves').select('video_id').eq('video_id', vid).eq('user_id', uid!)).isNotEmpty;

  static Future<void> setSaved(String vid, bool on) async {
    if (on) { await _db.from('saves').upsert({'video_id': vid, 'user_id': uid}); }
    else { await _db.from('saves').delete().match({'video_id': vid, 'user_id': uid!}); }
  }

  static Future<bool> isFollowing(String owner) async =>
      (await _db.from('follows').select('creator').eq('creator', owner).eq('follower', uid!)).isNotEmpty;

  static Future<void> setFollowing(String owner, bool on) async {
    if (owner == uid) return;
    if (on) { await _db.from('follows').upsert({'follower': uid, 'creator': owner}); }
    else { await _db.from('follows').delete().match({'follower': uid!, 'creator': owner}); }
  }

  static Future<void> view(String id) => _db.rpc('increment_views', params: {'vid': id});
}
