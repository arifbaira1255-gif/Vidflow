class Video {
  final String id, title, channel, thumb, ytId, category, views, age, desc, owner;
  const Video(this.id, this.title, this.channel, this.thumb, this.ytId, this.category, this.views, this.age, this.desc, this.owner);
}

const categories = ['For You', 'All', 'Music', 'Gaming', 'Learning', 'News', 'Sports', 'Tech'];
