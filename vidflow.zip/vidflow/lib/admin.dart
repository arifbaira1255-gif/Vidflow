import 'package:flutter/material.dart';
import 'repo.dart';
import 'models.dart';
import 'theme.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  final title = TextEditingController(), link = TextEditingController();
  String category = 'Music';
  bool isShort = false, busy = false;
  String? error;

  Future<void> submit() async {
    final id = extractYoutubeId(link.text);
    if (title.text.trim().isEmpty) return setState(() => error = 'Enter a title.');
    if (id == null) return setState(() => error = 'That link doesn\'t look like a YouTube video. Paste a watch, youtu.be, or Shorts link.');
    setState(() { busy = true; error = null; });
    try {
      await Repo.addVideo(title: title.text.trim(), category: category, isShort: isShort, url: link.text.trim(), ytId: id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Video added')));
      title.clear(); link.clear();
    } catch (e) {
      error = e.toString().contains('duplicate') ? 'This video is already in VidFlow.' : 'Couldn\'t add the video. Check that your account is an admin.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Admin panel')),
        body: ListView(padding: const EdgeInsets.all(20), children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'Title')),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: category, dropdownColor: C.surface, decoration: const InputDecoration(labelText: 'Category'),
            items: [for (final c in categories.skip(2)) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => category = v!),
          ),
          SwitchListTile(contentPadding: EdgeInsets.zero, value: isShort, onChanged: (v) => setState(() => isShort = v), title: const Text('Is Short?')),
          TextField(controller: link, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'YouTube video link')),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: C.coral))),
          const SizedBox(height: 24),
          FilledButton(style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)), onPressed: busy ? null : submit, child: Text(busy ? 'Adding...' : 'Submit video')),
        ]),
      );
}
