import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'models.dart';
import 'repo.dart';
import 'theme.dart';

class ShortsScreen extends StatefulWidget {
  const ShortsScreen({super.key});
  @override
  State<ShortsScreen> createState() => _ShortsScreenState();
}

class _ShortsScreenState extends State<ShortsScreen> {
  List<Video> list = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    Repo.videos(shorts: true).then((v) { if (mounted) setState(() { list = v; loading = false; }); });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator(color: C.accent));
    if (list.isEmpty) return const Center(child: Text('No Shorts yet. Upload one and switch on "This is a Short".', textAlign: TextAlign.center, style: TextStyle(color: C.muted)));
    return PageView.builder(
      scrollDirection: Axis.vertical,
      physics: const PageScrollPhysics(parent: BouncingScrollPhysics()),
      itemCount: list.length,
      itemBuilder: (_, i) => _ShortPage(list[i]),
    );
  }
}

class _ShortPage extends StatefulWidget {
  final Video v;
  const _ShortPage(this.v);
  @override
  State<_ShortPage> createState() => _ShortPageState();
}

class _ShortPageState extends State<_ShortPage> {
  late final YoutubePlayerController c;
  int likes = 0, mine = 0;

  @override
  void initState() {
    super.initState();
    c = YoutubePlayerController(
      initialVideoId: widget.v.ytId,
      flags: const YoutubePlayerFlags(autoPlay: true, loop: true, enableCaption: false, hideControls: false),
    );
    Repo.reactions(widget.v.id).then((r) { if (mounted) setState(() { likes = r['like']!; mine = r['mine']!; }); });
    Repo.view(widget.v.id);
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  void _like() {
    final next = mine == 1 ? 0 : 1;
    setState(() { likes += next == 1 ? 1 : -1; mine = next; });
    Repo.react(widget.v.id, next);
  }

  void _comments() => showModalBottomSheet(
        context: context, isScrollControlled: true, backgroundColor: C.surface,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        builder: (_) => _CommentSheet(widget.v.id),
      );

  Widget _btn(IconData i, String label, VoidCallback f, {Color? color}) => GestureDetector(
        onTap: f,
        child: Column(children: [Icon(i, size: 32, color: color), const SizedBox(height: 2), Text(label, style: const TextStyle(fontSize: 12))]),
      );

  @override
  Widget build(BuildContext context) => ColoredBox(
        color: Colors.black,
        child: Stack(fit: StackFit.expand, children: [
          Center(child: YoutubePlayer(controller: c, aspectRatio: 9 / 16, showVideoProgressIndicator: true, progressIndicatorColor: C.accent)),
          const IgnorePointer(child: DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.center, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black54])))),
          Positioned(
            left: 16, bottom: 28, right: 84,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text('@${widget.v.channel}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
              const SizedBox(height: 6),
              Text(widget.v.title, maxLines: 2, overflow: TextOverflow.ellipsis),
            ]),
          ),
          Positioned(
            right: 14, bottom: 36,
            child: Column(children: [
              _btn(mine == 1 ? Icons.favorite : Icons.favorite_border, '$likes', _like, color: mine == 1 ? C.coral : null),
              const SizedBox(height: 22),
              _btn(Icons.chat_bubble_outline, 'Comments', _comments),
              const SizedBox(height: 22),
              _btn(Icons.share_outlined, 'Share', () => Share.share('Watch "${widget.v.title}" on VidFlow')),
            ]),
          ),
        ]),
      );
}

class _CommentSheet extends StatefulWidget {
  final String vid;
  const _CommentSheet(this.vid);
  @override
  State<_CommentSheet> createState() => _CommentSheetState();
}

class _CommentSheetState extends State<_CommentSheet> {
  List<Comment> list = [];
  final input = TextEditingController();

  Future<void> _load() async {
    final c = await Repo.comments(widget.vid);
    if (mounted) setState(() => list = c);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _send() async {
    final t = input.text.trim();
    if (t.isEmpty) return;
    input.clear();
    await Repo.addComment(widget.vid, t);
    _load();
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .6,
          child: Column(children: [
            const Padding(padding: EdgeInsets.all(16), child: Text('Comments', style: TextStyle(fontWeight: FontWeight.w700))),
            Expanded(
              child: list.isEmpty
                  ? const Center(child: Text('Be the first to comment.', style: TextStyle(color: C.muted)))
                  : ListView(children: [for (final c in list) ListTile(title: Text('@${c.user}', style: const TextStyle(fontSize: 12, color: C.muted)), subtitle: Text(c.text, style: const TextStyle(color: C.text)))]),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: TextField(controller: input, onSubmitted: (_) => _send(),
                  decoration: InputDecoration(hintText: 'Add a comment', fillColor: C.bg, suffixIcon: IconButton(icon: const Icon(Icons.send, color: C.accent), onPressed: _send))),
            ),
          ]),
        ),
      );
}
