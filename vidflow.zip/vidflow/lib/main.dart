import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'home.dart';
import 'other.dart';
import 'shorts.dart';
import 'theme.dart';
import 'repo.dart';
import 'auth.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  // await Firebase.initializeApp(); // after running: flutterfire configure
  runApp(const VidFlowApp());
}

class VidFlowApp extends StatelessWidget {
  const VidFlowApp({super.key});
  @override
  Widget build(BuildContext context) =>
      MaterialApp(title: 'VidFlow', debugShowCheckedModeBanner: false, theme: vidflowTheme(), home: const Gate(), scrollBehavior: const SmoothScroll());
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  static final pages = [const HomeScreen(), const ShortsScreen(), const SavedScreen(), const ProfileScreen()];

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: i, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (n) => setState(() => i = n),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.bolt_outlined), selectedIcon: Icon(Icons.bolt), label: 'Shorts'),
            NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark), label: 'Saved'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      );
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: Supabase.instance.client.auth.onAuthStateChange,
      builder: (_, __) => Repo.uid == null ? const AuthScreen() : const Shell(),
    );
  }
}
