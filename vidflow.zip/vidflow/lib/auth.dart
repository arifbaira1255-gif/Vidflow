import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'repo.dart';
import 'theme.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController(), pass = TextEditingController(), name = TextEditingController();
  bool signup = false, busy = false, hide = true;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (signup) {
        await Repo.signUp(email.text.trim(), pass.text, name.text.trim());
      } else {
        await Repo.signIn(email.text.trim(), pass.text);
      }
    } on AuthException catch (e) {
      error = e.message;
    } catch (_) {
      error = 'Something went wrong. Check your connection and try again.';
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF0B1F33), Color(0xFF0F3B4A)])),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(28),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('VidFlow', textAlign: TextAlign.center, style: TextStyle(fontSize: 38, fontWeight: FontWeight.w800, color: C.accent)),
                  const SizedBox(height: 8),
                  Text(signup ? 'Create your account' : 'Welcome back', textAlign: TextAlign.center, style: const TextStyle(color: C.muted)),
                  const SizedBox(height: 32),
                  if (signup) ...[
                    TextField(controller: name, decoration: const InputDecoration(labelText: 'Username', prefixIcon: Icon(Icons.alternate_email))),
                    const SizedBox(height: 14),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.mail_outline))),
                  const SizedBox(height: 14),
                  TextField(
                    controller: pass, obscureText: hide,
                    decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide))),
                  ),
                  if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: C.coral))),
                  const SizedBox(height: 24),
                  FilledButton(
                    style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
                    onPressed: busy ? null : submit,
                    child: Text(busy ? 'Please wait...' : (signup ? 'Sign up' : 'Log in')),
                  ),
                  TextButton(
                    onPressed: () => setState(() { signup = !signup; error = null; }),
                    child: Text(signup ? 'Already have an account? Log in' : 'New here? Create an account'),
                  ),
                ]),
              ),
            ),
          ),
        ),
      );
}
